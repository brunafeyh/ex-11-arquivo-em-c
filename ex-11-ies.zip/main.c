/*11. Fac¸a um programa no qual o usuario informa o nome do arquivo e uma palavra, e retorne ´
o numero de vezes que aquela palavra aparece no arquivo. 

BRUNA CAROLINA DA SILVA FEYH 
23/08/2023
*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

#define MAX 1000



int contador(char ch[], char ch2[]){
    int c = 0;
    const char *encontrado = ch;

    while ((encontrado = strstr(encontrado, ch2)) != NULL) {
        c++;
        encontrado += strlen(ch2); // Avança para evitar contagem duplicada.
    }

    return c;
}

int lerarq(char *s, char str[]){
    FILE *f;
    f = fopen(s, "r");
    if(f == NULL) return errno;
    
    fscanf(f, "%[^EOF]", str);
 
    fclose(f);
    return 0;
}
int main()
{
    char ch[MAX], ch2[MAX];

    int erro;
    
    erro = lerarq("arq.txt" , ch);
    if(erro != 0) printf("erro de leitura: %d\n", erro);

    
    scanf("%s", ch2);
    printf("%d", contador(ch, ch2));
   
    return 0;
}
